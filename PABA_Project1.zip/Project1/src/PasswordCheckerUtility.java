import java.util.regex.*;
import java.util.ArrayList;
public class PasswordCheckerUtility {
	
	public PasswordCheckerUtility()
	{
		
	}
	public static void comparePasswords​(java.lang.String password, java.lang.String passwordConfirm) throws UnmatchedException
	{
		if(password.equals(passwordConfirm)==false)
			throw new UnmatchedException();
		
	}
	public static boolean comparePasswordsWithReturn​(java.lang.String password, java.lang.String passwordConfirm) throws UnmatchedException
	{
		if(password.equals(passwordConfirm)==false)
			throw new UnmatchedException();
		return true;
		
	}
	public static boolean isValidPassword​(java.lang.String password) throws LengthException, NoUpperAlphaException,
	  NoLowerAlphaException, NoDigitException, 
	  NoSpecialCharacterException, InvalidSequenceException
{
try {
isValidLength​(password);
hasUpperAlpha​(password);
hasLowerAlpha​(password);
hasDigit​(password);
hasSpecialChar​(password);
NoSameCharInSequence​(password);
return true;


}

catch(LengthException e)
{
System.out.println(e.getMessage());
}
catch(NoUpperAlphaException e)
{
System.out.println(e.getMessage());
}
catch(NoLowerAlphaException e)
{
System.out.println(e.getMessage());
}
catch(NoDigitException e)
{
System.out.println(e.getMessage());
}
catch(NoSpecialCharacterException e)
{
System.out.println(e.getMessage());
}
catch(InvalidSequenceException e)
{
System.out.println(e.getMessage());
}
return false;
}
	
	public static boolean isWeakPassword​(java.lang.String password) throws WeakPasswordException
	{
		
		try {
			if(isValidPassword​(password) == true && hasBetweenSixAndNineChars​(password))
				throw new WeakPasswordException();
		} catch (LengthException e) {
		
			e.getMessage();
		} catch (NoUpperAlphaException e) {
			
			e.getMessage();
		} catch (NoLowerAlphaException e) {
			
			e.getMessage();
		} catch (NoDigitException e) {
			
			e.getMessage();
		} catch (NoSpecialCharacterException e) {
			
			e.getMessage();
		} catch (InvalidSequenceException e) {
			
			e.getMessage();
		} catch (WeakPasswordException e) {
		
			e.getMessage();
		}
		return false;
	}
	public static java.util.ArrayList<java.lang.String> getInvalidPasswords​(java.util.ArrayList<java.lang.String> passwords)
	{
		ArrayList<String> newPasswordList = new ArrayList<String>();
		for(String pass : passwords)
		{
			
			try {
				pass+=" "+isValidPassword​(pass);
				newPasswordList.add(pass);
			} catch (LengthException e) {
				pass+=" "+e.getMessage();
				newPasswordList.add(pass);
			} catch (NoUpperAlphaException e) {
				pass+=" "+e.getMessage();
				newPasswordList.add(pass);
			} catch (NoLowerAlphaException e) {
				pass+=" "+e.getMessage();
				newPasswordList.add(pass);
			} catch (NoDigitException e) {
				pass+=" "+e.getMessage();
				newPasswordList.add(pass);
			} catch (NoSpecialCharacterException e) {
				pass+=" "+e.getMessage();
				newPasswordList.add(pass);
			} catch (InvalidSequenceException e) {
				pass+=" "+e.getMessage();
				newPasswordList.add(pass);
			} 
		}
		return newPasswordList;
	}

	public static boolean isValidLength​(java.lang.String password) throws LengthException
	{
		if(password.length()>=6)
			return true;
		throw new LengthException();
	}
	
	public static boolean hasUpperAlpha​(java.lang.String password) throws NoUpperAlphaException
	{
		for(int i = 0;i<password.length();i++)
		if(Character.isUpperCase( password.charAt(i) ) )
			return true;
		throw new NoUpperAlphaException();
	}
	public static boolean hasLowerAlpha​(java.lang.String password) throws NoLowerAlphaException
	{
		for(int i = 0;i<password.length();i++)
		if(Character.isLowerCase( password.charAt(i) ) )
			return true;
		throw new NoLowerAlphaException();
	}
	
	public static boolean hasDigit​(java.lang.String password) throws NoDigitException
	{
		for(int i = 0;i<password.length();i++)
		if(Character.isDigit( password.charAt(i) ) )
			return true;
		throw new NoDigitException();
	}
	public static boolean hasSpecialChar​(java.lang.String password) throws NoSpecialCharacterException
	{
		Pattern pattern = Pattern.compile("\\W");
		Matcher matcher = pattern.matcher(password);
		if (matcher.find())
		return true;

		throw new NoSpecialCharacterException();
	}
	public static boolean NoSameCharInSequence​(java.lang.String password) throws InvalidSequenceException
	{
		for(int i = 0;i<password.length()-2;i++)
			{if( password.charAt(i) == password.charAt(i+1)&& password.charAt(i)==password.charAt(i+2))
				throw new InvalidSequenceException();}
		return true;

		
	}
	public static boolean hasBetweenSixAndNineChars​(java.lang.String password)
	{
		if(password.length()>=6 && password.length()<=9)
			return true;
		return false;
	}
	
	
}
