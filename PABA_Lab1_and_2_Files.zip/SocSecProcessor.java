import java.util.Scanner;
public class SocSecProcessor {

	public static void main(String[] args)
	{
		char tryAgain;
		var sc = new Scanner(System.in);
		do{
			try
			{
			
			
		System.out.print("Name? ");
		String name = sc.nextLine();
		
		System.out.print("SSN? ");
		String ssn = sc.nextLine();
		
		isValid(ssn);
		System.out.println(name+" "+ssn+" is valid");
			}
			catch(SocSecException e)
			{
				System.out.println(e.getMessage());
			}
		
		System.out.print("Try again? ");
		 tryAgain = sc.nextLine().charAt(0);
		
			}while(tryAgain !='n' && tryAgain !='N');
		
	}
	public static boolean isValid(String ssn) throws SocSecException
	{
		
		if(ssn.length() != 11)
			throw new SocSecException(", invalid number of characters");
		if(ssn.charAt(3)!='-' || ssn.charAt(6)!='-')
			throw new SocSecException(", dashes at wrong position");
		
		for(int i = 0;i<ssn.length();i++)
		{
			if(Character.isDigit(ssn.charAt(i))== false &&(i!=3 && i!=6))
				throw new SocSecException(", contains atleast one character that is not a digit");
		}
		
		return true;
		
	}
}
