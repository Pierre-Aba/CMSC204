import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class GradeBookTester {

	private GradeBook g1;
	
	@BeforeEach
	void setUp() throws Exception {
		g1 = new GradeBook(5);
		g1.addScore(33);
		g1.addScore(66);
	}

	@AfterEach
	void tearDown() throws Exception {
		g1 = null;
	}


	

	@Test
	void testAddScore() {
		assertEquals(2, g1.getScoreSize(), .0001);
		
	}

	@Test
	void testSum() {
		assertEquals(99, g1.sum(), .0001);
	}

	@Test
	void testMinimum() {
		assertEquals(33, g1.minimum(), .001);	}

	@Test
	void testFinalScore() {
		assertEquals(2, g1.getScoreSize(), .0001);
	}

	@Test
	void testGetScoreSize() {
		assertEquals(2, g1.getScoreSize(), .0001);
	}

	@Test
	void testToString() {
		String testString = "33 66 ";
		assertEquals(testString, g1.toString());
	}
	
	

}
